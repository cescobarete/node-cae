var message = 'Hello World';
console.log(message);
console.log(Othermessage);